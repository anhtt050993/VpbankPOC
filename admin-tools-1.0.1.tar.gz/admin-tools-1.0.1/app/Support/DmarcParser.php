<?php declare(strict_types=1);

namespace App\Support;

use Webklex\PHPIMAP\Message;

class DmarcParser
{
    const EMPTY_NODE_XPATH = '//*[not(text())]';

    public static function parseMessage(Message $message): array
    {
        $reports = [];

        $attachments = $message->attachments();
        foreach ($attachments as $attachment) {
            $xml = false;
            switch ($attachment->content_type) {
                case 'application/zip':
                case 'application/x-zip-compressed':
                    $xml = self::unzip($attachment->content);
                    break;
                case 'application/gzip':
                case 'application/x-gzip':
                    $xml = self::gunzip($attachment->content);
                    break;
                case 'application/xml':
                    $xml = $attachment->content;
                    break;
            }
            if (!empty($xml)) {
                $report = self::parseXml($xml);
                if (!empty($report)) {
                    $reports[] = $report;
                }
            }
        }

        return $reports;
    }

    private static function parseXml(string $content): mixed
    {
        $xml = @simplexml_load_string($content);
        if (!$xml) {
            return false;
        }
        foreach ($xml->xpath(self::EMPTY_NODE_XPATH) as $remove) {
            unset($remove[0]);
        }

        $report = json_decode(json_encode($xml));
        unset($xml);

        // Adjust to array unconditionally
        if (is_array($report->record)) {
            $report->records = $report->record;
        }
        else {
            $report->records = array($report->record);
        }
        unset($report->record);

        return $report;
    }

    private static function unzip(string $data): string | bool
    {
        $head = unpack(
            'Vsig/vver/vflag/vmeth/vmodt/vmodd/Vcrc/Vcsize/Vsize/vnamelen/vexlen',
            substr($data, 0, 30)
        );
        return gzinflate(substr(
            $data,
            30 + $head['namelen'] + $head['exlen'],
            $head['csize']
        ));
    }

    private static function gunzip(string $data): string | bool
    {
        if (function_exists('gzdecode')) {
            return gzdecode($data);
        }
        else {
            return self::gzdecode($data);
        }
    }

    private static function gzdecode(
        string $data, string &$fileName = ''
    ): string | bool
    {
        $len = strlen($data);
        if ($len < 18 || strcmp(substr($data, 0, 2), "\x1f\x8b")) {
            logger()->error('gzdecode: not in gzip format.');
            return false;  // Not GZIP format (See RFC 1952)
        }
        $method = ord(substr($data, 2, 1));  // Compression method
        $flags  = ord(substr($data, 3, 1));  // Flags
        if ($flags & 31 != $flags) {
            logger()->error('gzdecode: reserved bits not allowed.');
            return false;
        }
        // NOTE: $mtime may be negative (PHP integer limitations)
        $mtime = unpack("V", substr($data, 4, 4));
        $mtime = $mtime[1];
        $xfl   = substr($data, 8, 1);
        $os    = substr($data, 8, 1);
        $headerLen = 10;
        $extraLen  = 0;
        $extra     = '';
        if ($flags & 4) {
            // 2-byte length prefixed EXTRA data in header
            if ($len - $headerLen - 2 < 8) {
                return false;  // invalid
            }
            $extraLen = unpack("v", substr($data, 8, 2));
            $extraLen = $extraLen[1];
            if ($len - $headerLen - 2 - $extraLen < 8) {
                return false;  // invalid
            }
            $extra = substr($data, 10, $extraLen);
            $headerLen += 2 + $extraLen;
        }
        $fileNameLen = 0;
        $fileName = '';
        if ($flags & 8) {
            // C-style string
            if ($len - $headerLen - 1 < 8) {
                return false; // invalid
            }
            $fileNameLen = strpos(substr($data, $headerLen), chr(0));
            if ($fileNameLen === false || $len - $headerLen - $fileNameLen - 1 < 8) {
                return false; // invalid
            }
            $fileName = substr($data, $headerLen, $fileNameLen);
            $headerLen += $fileNameLen + 1;
        }
        $commentLen = 0;
        $comment = '';
        if ($flags & 16) {
            // C-style string COMMENT data in header
            if ($len - $headerLen - 1 < 8) {
                return false;    // invalid
            }
            $commentLen = strpos(substr($data, $headerLen), chr(0));
            if ($commentLen === false || $len - $headerLen - $commentLen - 1 < 8) {
                return false;    // Invalid header format
            }
            $comment = substr($data, $headerLen, $commentLen);
            $headerLen += $commentLen + 1;
        }
        $headerCrc = '';
        if ($flags & 2) {
            // 2-bytes (lowest order) of CRC32 on header present
            if ($len - $headerLen - 2 < 8) {
                return false;    // invalid
            }
            $calccrc = crc32(substr($data, 0, $headerLen)) & 0xffff;
            $headerCrc = unpack("v", substr($data, $headerLen, 2));
            $headerCrc = $headerCrc[1];
            if ($headerCrc != $calccrc) {
                logger()->error('gzdecode: header checksum failed.');
                return false;    // Bad header CRC
            }
            $headerLen += 2;
        }
        // GZIP FOOTER
        $datacrc = unpack("V", substr($data, -8, 4));
        $datacrc = sprintf('%u', $datacrc[1] & 0xFFFFFFFF);
        $isize = unpack("V", substr($data, -4));
        $isize = $isize[1];
        // decompression:
        $bodylen = $len - $headerLen-8;
        if ($bodylen < 1) {
            // IMPLEMENTATION BUG!
            return null;
        }
        $body = substr($data, $headerLen, $bodylen);
        $data = '';
        if ($bodylen > 0) {
            switch ($method) {
            case 8:
                // Currently the only supported compression method:
                $data = gzinflate($body);
                break;
            default:
                logger()->error('gzdecode: unknown compression method.');
                return false;
            }
        }  // zero-byte body content is allowed
        // Verifiy CRC32
        $crc   = sprintf("%u", crc32($data));
        $crcOK = $crc == $datacrc;
        $lenOK = $isize == strlen($data);
        if (!$lenOK || !$crcOK) {
            $error = ($lenOK ? '' : 'length check failed. ') . ( $crcOK ? '' : 'checksum failed.');
            logger()->error("gzdecode: $error");
            return false;
        }
        return $data;
    }
}
