<?php declare(strict_types=1);

namespace App\Support;

use App\Models\{
    DkimKey,
    X509Certificate,
    X509SigningRequest,
};
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\Response;

final class Helper
{
    /**
     * Generate random password.
     *
     * @param int $length
     * @return string
     */
    public static function randomPassword(int $length = 32): string
    {
        return Str::password($length);
    }

    /**
     * Export Dkim key.
     *
     * @param DkimKey $record
     * @return Response
     */
    public static function exportDkimKey(
        DkimKey $record
    ): Response
    {
        $filePath = tempnam(
            sys_get_temp_dir(), $record->selector
        );
        file_put_contents($filePath, $record->private_key);
        return response()->download(
            $filePath, $record->selector . '.key', [
                'Content-Type' => 'application/pkcs8',
            ]
        )->deleteFileAfterSend(true);
    }

    /**
     * Export Dkim dns record.
     *
     * @param DkimKey $record
     * @return Response
     */
    public static function exportDkimDnsRecord(
        DkimKey $record
    ): Response
    {
        $filePath = tempnam(
            sys_get_temp_dir(), $record->selector
        );
        file_put_contents($filePath, $record->dns_record);
        return response()->download(
            $filePath, $record->selector . '.txt', [
                'Content-Type' => 'plain/txt',
            ]
        )->deleteFileAfterSend(true);
    }

    /**
     * Export X509 key.
     *
     * @param X509SigningRequest $record
     * @return Response
     */
    public static function exportX509Key(
        X509SigningRequest $record
    ): Response
    {
        $filePath = tempnam(
            sys_get_temp_dir(), $record->cn
        );
        file_put_contents($filePath, $record->key_data);
        return response()->download(
            $filePath, $record->cn . '.key', [
                'Content-Type' => 'application/pkcs8',
            ]
        )->deleteFileAfterSend(true);
    }

    /**
     * Export X509 Certificate Signing Request.
     *
     * @param X509SigningRequest $record
     * @return Response
     */
    public static function exportX509Csr(
        X509SigningRequest $record
    ): Response
    {
        $filePath = tempnam(
            sys_get_temp_dir(), $record->cn
        );
        file_put_contents($filePath, $record->csr_data);
        return response()->download(
            $filePath, $record->cn . '.csr', [
                'Content-Type' => 'application/pkcs',
            ]
        )->deleteFileAfterSend(true);
    }

    /**
     * Export X509 Certificate.
     *
     * @param X509Certificate $record
     * @return Response
     */
    public static function exportX509Certificate(
        X509Certificate $record
    ): Response
    {
        $filePath = tempnam(
            sys_get_temp_dir(), $record->serial_number
        );
        file_put_contents($filePath, $record->certificate_data);
        return response()->download(
            $filePath, $record->csr->cn . '.cert', [
                'Content-Type' => 'application/pkcs',
            ]
        )->deleteFileAfterSend(true);
    }
}
