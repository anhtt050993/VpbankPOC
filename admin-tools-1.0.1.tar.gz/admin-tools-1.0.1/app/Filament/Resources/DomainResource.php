<?php declare(strict_types=1);

namespace App\Filament\Resources;

use App\Filament\Resources\DomainResource\Pages;
use App\Models\Domain;
use Filament\Resources\Resource;

class DomainResource extends Resource
{
    protected static ?string $model = Domain::class;
    protected static ?string $navigationGroup = 'Domain';
    protected static ?string $navigationIcon = 'heroicon-o-globe-alt';
    protected static ?string $slug = 'domain';

    public static function getNavigationLabel(): string
    {
        return __('Domain Manager');
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListDomains::route('/'),
            'create' => Pages\CreateDomain::route('/create'),
            'edit' => Pages\EditDomain::route('/{record}/edit'),
        ];
    }
}
