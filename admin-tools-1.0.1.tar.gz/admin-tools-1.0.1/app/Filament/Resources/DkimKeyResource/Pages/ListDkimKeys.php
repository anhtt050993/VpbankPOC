<?php declare(strict_types=1);

namespace App\Filament\Resources\DkimKeyResource\Pages;

use Amp\Dns\DnsRecord;
use Amp\Dns\DnsException;
use App\Filament\Resources\DkimKeyResource;
use App\Models\DkimKey;
use App\Models\Domain;
use App\Support\Helper;
use Filament\Actions\Action as HeaderAction;
use Filament\Infolists\Components\TextEntry;
use Filament\Resources\Pages\ListRecords;
use Filament\Tables\{
    Actions\Action,
    Actions\ActionGroup,
    Columns\TextColumn,
    Filters\SelectFilter,
    Table,
};

class ListDkimKeys extends ListRecords
{
    protected static string $resource = DkimKeyResource::class;

    public function getTitle(): string
    {
        return __('DKIM Keys');
    }

    public function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('domain.name')->label(__('Domain')),
            TextColumn::make('selector')->label(__('Selector')),
            TextColumn::make('key_bits')->label(__('Key Bits')),
        ])->filters([
            SelectFilter::make('domain_id')->options(
                Domain::all()->pluck('name', 'id')
            )->label(__('Domain')),
        ])->actions([
            ActionGroup::make([
                Action::make('query_dkim_record')
                    ->infolist([
                        TextEntry::make('dkim_record')
                            ->state(fn ($record) => self::queryDkimRecord($record))
                            ->html()->label(__('Result')),
                    ])
                    ->modalHeading(__('Query Dkim Record'))
                    ->modalSubmitAction(false)
                    ->icon('heroicon-m-eye')->label(__('Query Dkim Record')),
                Action::make('export_key')->label(__('Export Private Key'))
                    ->icon('heroicon-m-arrow-down-tray')
                    ->action(
                        fn ($record) => Helper::exportDkimKey($record)
                    ),
                Action::make('export_csr')->label(__('Export Dns Record'))
                    ->icon('heroicon-m-arrow-down-tray')
                    ->action(
                        fn ($record) => Helper::exportDkimDnsRecord($record)
                    ),
            ]),
        ])->defaultSort('created_at', 'desc');
    }

    private static function queryDkimRecord(DkimKey $dkim): string
    {
        try {
            $records = array_map(
                fn ($record) => $record->getValue(),
                \Amp\Dns\query(
                    $dkim->selector . '._domainkey.' . $dkim->domain->name,
                    DnsRecord::TXT
                )
            );
            return implode('<br />', $records);
        }
        catch (DnsException $e) {
            return $e->getMessage();
        }
    }

    protected function getHeaderActions(): array
    {
        return [
            HeaderAction::make('gen')
                ->url(static::getResource()::getUrl('gen'))
                ->label(__('Generate DKIM Key')),
        ];
    }
}
