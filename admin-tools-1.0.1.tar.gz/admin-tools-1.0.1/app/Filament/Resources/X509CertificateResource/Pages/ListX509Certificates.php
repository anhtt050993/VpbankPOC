<?php declare(strict_types=1);

namespace App\Filament\Resources\X509CertificateResource\Pages;

use App\Filament\Resources\X509CertificateResource;
use App\Models\Domain;
use App\Support\Helper;
use Filament\Forms\Components\TextInput;
use Filament\Resources\Pages\ListRecords;
use Filament\Tables\{
    Actions\Action,
    Columns\TextColumn,
    Filters\Filter,
    Filters\SelectFilter,
    Table,
};
use Illuminate\Database\Eloquent\Builder;

class ListX509Certificates extends ListRecords
{
    protected static string $resource = X509CertificateResource::class;

    public function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('subject_dn')->wrap()->label(__('Subject DN')),
            TextColumn::make('issuer_dn')->wrap()->label(__('Issuer DN')),
            TextColumn::make('serial_number')->formatStateUsing(
                static fn (string $state): string => strtoupper($state)
            )->label(__('Serial Number')),
            TextColumn::make('not_before')->wrap()->label(__('Not Before')),
            TextColumn::make('not_after')->wrap()->label(__('Not After')),
        ])->filters([
            Filter::make('filter')->form([
                TextInput::make('subject_dn')->label(__('Subject DN')),
            ])->query(
                fn (Builder $query, array $data) => $query->when(
                    $data['subject_dn'],
                    fn (Builder $query, string $dn) => $query->where(
                        'subject_dn', 'like', '%' . trim($dn) . '%'
                    )
                )
            ),
            SelectFilter::make('domain_id')
                ->options(
                    Domain::all()->pluck('name', 'id')
                )->label(__('Domain')),
        ])->actions([
            Action::make('export_cert')->label(__('Export'))
                ->icon('heroicon-m-arrow-down-tray')
                ->action(
                    fn ($record) => Helper::exportX509Certificate($record)
                ),
        ])->defaultSort('created_at', 'desc');
    }
}
