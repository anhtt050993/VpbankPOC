<?php declare(strict_types=1);

namespace App\Filament\Resources;

use App\Filament\Resources\DkimKeyResource\Pages;
use App\Models\DkimKey;
use Filament\Resources\Resource;

class DkimKeyResource extends Resource
{
    protected static ?string $model = DkimKey::class;
    protected static ?string $navigationGroup = 'Domain';
    protected static ?string $navigationIcon = 'heroicon-o-key';

    public static function getNavigationLabel(): string
    {
        return __('DKIM Keys');
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListDkimKeys::route('/'),
            'gen' => Pages\GenDkimKey::route('/gen'),
        ];
    }
}
