<?php declare(strict_types=1);

namespace App\Filament\Resources\DomainResource\Pages;

use App\Filament\Resources\DomainResource;
use Filament\Forms\{
    Components\Hidden,
    Components\Textarea,
    Components\TextInput,
    Form,
    Get,
};
use Filament\Resources\Pages\CreateRecord;
use Illuminate\Support\Str;

class CreateDomain extends CreateRecord
{
    protected static string $resource = DomainResource::class;
    protected static bool $canCreateAnother = false;

    public function form(Form $form): Form
    {
        return $form->schema([
            TextInput::make('name')
                ->rules([
                    fn () => function (string $attribute, $value, \Closure $fail) {
                        if (!filter_var($value, FILTER_VALIDATE_DOMAIN)) {
                            $fail(__('The domain name is invalid.'));
                        }
                    },
                ])
                ->required()->unique()->label(__('Name')),
            TextInput::make('email')
                ->rules([
                    fn (Get $get) => function (
                        string $attribute, $value, \Closure $fail
                    ) use ($get) {
                        if (!Str::endsWith($value, $get('name'))) {
                            $fail(__('The email address must match the domain name.'));
                        }
                    },
                ])->email()->required()->unique()->label(__('Email Address')),
            TextInput::make('organization')
                ->columnSpan(2)->label(__('Organization')),
            Textarea::make('description')
                ->columnSpan(2)->label(__('Description')),
            Hidden::make('created_by')->default(auth()->user()->id),
        ]);
    }

    protected function getCreatedNotificationTitle(): ?string
    {
        return __('Domain has been created!');
    }

    protected function getRedirectUrl(): string
    {
        return static::getResource()::getUrl();
    }
}
