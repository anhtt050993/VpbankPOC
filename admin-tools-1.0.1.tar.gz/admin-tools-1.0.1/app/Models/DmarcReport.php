<?php declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Model;

class DmarcReport extends Model
{
    use HasFactory;

    protected $table = 'dmarc_reports';

    protected $fillable = [
        'report_id',
        'org_name',
        'org_email',
        'extra_contact',
        'date_begin',
        'date_end',
        'domain',
        'adkim',
        'aspf',
        'policy',
        'subdomain_policy',
        'percentage',
        'is_forensic',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'is_forensic' => 'boolean',
    ];

    public function records(): HasMany
    {
        return $this->hasMany(DmarcReportRecord::class, 'report_id', 'report_id');
    }
}
